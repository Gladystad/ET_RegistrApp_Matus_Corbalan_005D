import { browser, by, element } from 'protractor';

export class AppPage {
  navigateTo() {
    return browser.get('/');
  }


  getTitleText(){
    return element(by.css('app-root p')).getText();
  }

  getPageTitle2(){
    return element(by.css('app-root ion-card-title')).getText();
  }

  getPageButtonTitle(){
    return element(by.css('app-root ion-button')).getText();
  }

  getPageLabelText(){
    return element(by.css('app-root ion-label')).getText();
  }

  getTitleTextH5(){
    return element(by.css('app-root h5')).getText();
  }
}
